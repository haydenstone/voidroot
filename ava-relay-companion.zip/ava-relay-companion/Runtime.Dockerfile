FROM archlinux:base
RUN printf 'Server = http://127.0.0.1:8791/arch/$repo/os/$arch\n' > /etc/pacman.d/mirrorlist
RUN pacman -Syu --disable-download-timeout --noconfirm python nodejs npm git vim base-devel curl iproute2 procps-ng xfce4 tigervnc python-pip python-numpy python-setuptools dbus xdotool imagemagick qemu-desktop chromium xfce4-terminal sudo adwaita-icon-theme librsvg plasma-desktop plasma-x11-session kwin-x11 dolphin konsole breeze-icons zenity && pacman -Scc --noconfirm
RUN useradd -m ava
COPY build-assets/novnc /opt/novnc
COPY build-assets/wheels /opt/wheels
RUN python -m venv --system-site-packages /opt/desktop-venv && /opt/desktop-venv/bin/pip install --no-deps --no-index --find-links=/opt/wheels websockify
ENV PATH="/opt/desktop-venv/bin:$PATH"
COPY stash.py /opt/stash.py
COPY stash-pip stash-git ava-browser /usr/local/bin/
RUN chmod +x /usr/local/bin/stash-pip /usr/local/bin/stash-git /usr/local/bin/ava-browser
ENV AVACHORD_HOME=/avachord npm_config_cache=/avachord/stash/npm npm_config_prefer_offline=true PIP_FIND_LINKS=/avachord/stash/wheels
WORKDIR /workspace
COPY bootstrap.sh desktop-session.sh desktop-login.sh /opt/
CMD ["/bin/bash","/opt/bootstrap.sh"]
