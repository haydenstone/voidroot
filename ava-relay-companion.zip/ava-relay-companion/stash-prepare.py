import os,pathlib,subprocess,sys,shutil,json,time
root=pathlib.Path(__file__).resolve().parent;stash=pathlib.Path(os.getenv('AVACHORD_HOME',str(pathlib.Path.home()/'Documents/avachord')))/'stash';stash.mkdir(parents=True,exist_ok=True);assets=root/'build-assets';assets.mkdir(exist_ok=True)
def run(cmd):subprocess.run(cmd,cwd=root,check=True)
# A source mirror is reused until an explicit stash-update fetch.
repo=stash/'git/noVNC.git'
if not repo.exists():repo.parent.mkdir(parents=True,exist_ok=True);run(['git','clone','--mirror','https://github.com/novnc/noVNC.git',str(repo)])
if (assets/'novnc').exists():shutil.rmtree(assets/'novnc')
run(['git','clone',str(repo),str(assets/'novnc')]);run(['git','-C',str(assets/'novnc'),'checkout','v1.6.0']);shutil.copyfile(root/'desktop.html',assets/'novnc/desktop.html')
venv=stash/'python-venv'
if not venv.exists():run([sys.executable,'-m','venv',str(venv)])
wheels=stash/'wheels';wheels.mkdir(exist_ok=True)
if not (stash/'wheels.complete').exists():
 run([str(venv/'bin/python'),'-m','pip','download','--no-deps','--dest',str(wheels),'websockify']);(stash/'wheels.complete').write_text(str(time.time()))
if (assets/'wheels').exists():shutil.rmtree(assets/'wheels')
shutil.copytree(wheels,assets/'wheels')
images=stash/'images';images.mkdir(exist_ok=True);base=images/'archlinux-base.tar'
if base.exists():run(['docker','load','-i',str(base)])
else:run(['docker','pull','archlinux:base']);run(['docker','save','-o',str(base),'archlinux:base'])
