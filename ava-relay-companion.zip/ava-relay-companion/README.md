# AVA / Chord Projects · revision 2.4

## Start

Requirements: Linux x86_64, Docker Engine + Compose, Python with venv/ensurepip, Git, and permission to run Docker. Run `python3 manage.py doctor` to inspect prerequisites.

1. Run `python3 manage.py install`. First run creates a protected .env and stops for configuration.
2. Set SITE_ORIGIN to https://ava-three-node-relay.hayden-stone-og739.chatgpt.site. Optional provider keys enable direct GPT/Gemini/Claude calls. No provider key is needed for manual CLI, desktop or MCP commands.
3. Rerun install. It prepares the local stash, builds Arch images, starts the host broker, main Arch controller and provider proxy. The first build can download several GB.
4. Open http://127.0.0.1:8790 for the local panel or http://127.0.0.1:6090/vnc.html for the Arch control desktop. Desktop password is CONTROL_DESKTOP_PASSWORD from .env; upgrades must add it if absent.
5. Pair using RELAY_TOKEN and http://127.0.0.1:8789. Main Arch XFCE opens the local panel in Chromium under the ava user.

## Architecture

The browser / chat control surface sends authenticated requests to the main Arch nest controller (:8789). It forwards bounded operations to the host Docker broker (:8788), which manages project containers. Children are Docker siblings grouped in one nest; no Docker socket or host-root mount is passed into the controller or project containers. The provider proxy uses :8787. Desktop/input tools can target the main controller ava-relay-nest-1.

Arch containers share the Linux host kernel. This is not an Arch VM booted inside the browser. XFCE is viewed through noVNC; packaged Chromium runs inside the control container. Chromium's sandbox remains enabled and depends on host user-namespace support.

## Projects

Create projects with an app host/container port. Ports 1024–65535 bind only to host 127.0.0.1; control ports are reserved. Bootstrap serves /workspace via Python at the chosen container port. Open app opens that published URL; the IDE reads/writes actual project text files and provides root CLI, file explorer, save, app launch and preview. Servers must bind to 0.0.0.0 inside the project. Desktop projects use a separate noVNC port, 4 GB RAM and two CPUs.

Start, stop, restart, logs, successor staging and retirement are supported. Successors get a separate workspace and must use unoccupied ports while the previous project is running. No automatic migration or readiness-based traffic cutover is claimed. Retirement preserves the host workspace.

## Local volume and stash

Authoritative root: ~/Documents/avachord (override with AVACHORD_HOME).
- projects/<name>/workspace: project files, source, app logs, VM disks.
- control: main control workspace.
- stash/arch: cached Arch repository metadata and package archives.
- stash/wheels: local Python wheelhouse.
- stash/git: source mirrors.
- stash/images: base/runtime Docker image archives.
- stash/npm: npm prefer-offline cache.
- stash/artifacts and stash/receipts: explicit downloads and SHA-256 receipts.

The installer serves its local Arch mirror at :8791. Each project runs a loopback cache backed by the shared stash. Arch pacman, stash-pip, stash-git and npm use local cache paths first. Cached metadata is retained until `stash-update`. Arbitrary root shell scripts can bypass these helpers; this is not an enforced all-protocol egress mirror. The stash is for a trusted single-user host, and container-written files may be owned by root.

## Desktop and virtualization

Arch projects include XFCE, TigerVNC, noVNC, Chromium, QEMU desktop, Python, Node, Git and build tools. The main control container opens the panel in Chromium. Desktop screenshot/click/type/key operate actual XFCE displays. Optional KVM passes only /dev/kvm to selected projects and fails if absent. No QEMU guest ISO/disk is bundled, installed or booted; supply a guest image and launch QEMU through project CLI. Browser mixed-content policies can block HTTP previews; Open app/full console are provided.

## Commands from this conversation

Install the Site's provisioned plugin. Point a secured HTTPS endpoint at the nest controller :8789, preserving Bearer authentication. Configure BROKER_URL and RELAY_TOKEN as Site runtime secrets and republish. MCP exposes relay_status, list_projects, deploy_project, project_lifecycle, project_logs, execute_project_cli, start_project_app, project_files, desktop_screenshot and desktop_input. These use no model API key. Until transport and plugin are connected, relay_status honestly reports unpaired and commands cannot execute on your machine.

Optional API-provider tasks require provider credentials and run up to five JSON-directed commands, 30 seconds each. They are separate from chat MCP tools. The one-line Connect overlay and bookmarklet open a movable authenticated control panel; they do not bypass browser permission or independently connect this conversation.

## Lifecycle

`python3 manage.py doctor|install|status|logs|stop|uninstall|stash-status|stash-update`
`python3 stash-get.py https://public-artifact-url`

Stop/uninstall preserve Documents/avachord. Projects remain until retired. Broker and stash logs are in the extracted companion folder. The session activity stream is not a durable audit database. See FEATURES.md for the first-run audit and validation limits.

## Terminal control station and uninstall

Run `python3 tui.py` (or `python3 manage.py` with no arguments) for the responsive terminal grid: Install/update, Service status, Projects, Logs, Stash, Refresh, Stop, Uninstall, Full uninstall. Arrow keys navigate; Enter runs; D installs dependencies; C checks prerequisites. Commands stream directly before returning to the grid.

`python3 manage.py dependencies` installs Docker, Compose, Git and Python venv using native packages on Ubuntu/Arch and starts Docker. It requires sudo/admin rights. Other distributions receive a clear prerequisites message. It does not remove globally shared host software or change Docker group membership.

`uninstall` removes companion services/images and stops host workers while retaining projects and Documents/avachord. `purge` additionally removes AVA project containers, the runtime image and avachord storage after a typed ERASE AVACHORD confirmation. The terminal dashboard provides that explicit confirmation. Host Docker/Git/Python are preserved because they may serve unrelated work.

## ChatGPT / Gemini one-line sidecar

Connection → Copy one-line JS copies a self-contained shadow-DOM sidecar. Run it in the browser console on chatgpt.com or gemini.google.com, or use the bookmarklet. It loads no external script and no authenticated iframe. Enter your pairing token, Connect, select a project, then Run command. Exact origins are allowed by the local broker. Browser CSP/PNA restrictions cannot be bypassed; the sidecar reports errors and provides Open local control panel. A page's optional WebMCP support does not imply this chat has installed the Sites MCP plugin.

## Download timeout repair and fullscreen

The stash now streams cache misses to pacman as bytes arrive, retains atomic package files, checks upstream Content-Length and hashes incrementally. Interrupted clients can leave the download running to completion; failed upstream transfers never become complete cache entries. The Arch build disables pacman's low-speed timeout to tolerate slow cache fills. Upstream socket timeout remains 180 seconds.

After updating the extracted companion, run `python3 manage.py stop`, `python3 manage.py repair-stash`, then `python3 manage.py install`. Repair removes only incomplete Arch .partial/.part files and preserves complete cache, project data, configuration and mirrors. Do not prune Docker globally or delete Documents/avachord.

Interactive desktops now open desktop.html with Full screen, Exit full screen, Fit to window and Resize desktop. Main control desktop: http://127.0.0.1:6090/desktop.html. Project links use their published desktop port. Browsers require a user click for fullscreen; Escape exits. The screenshot pane also supports fullscreen but is distinct from the interactive viewer.


## Signature download recovery (2.2)

The stash now retries transient failures, falls back from the primary mirror to kernel.org and the Arch package archive, and retains successfully fetched signatures locally. All-upstream 404/410 is reported as 404 rather than a misleading 502; other failures log each attempted URL/status to stash.log. Package signature verification stays enabled.

After replacing companion files while preserving .env:
`python3 manage.py stop`
`python3 manage.py repair-stash --refresh-metadata`
`python3 manage.py install`

This removes incomplete files plus cached repository metadata so pacman sees current package versions, while retaining full package archives, signature files, Git/Python caches and project workspaces. Build failures now display a targeted recovery message instead of a Python traceback.


## Address-family repair (2.3)

The stash downloader now defaults to IPv4-only DNS/socket connections. It preserves HTTPS hostnames, SNI, certificate validation and supported proxy handling, and does not modify global host IPv6 settings. STASH_ADDRESS_FAMILY=auto opts back into the standard dual-stack downloader. /status reports the active mode.

Expected 404s for optional repository .db.sig files remain real 404 responses but no longer flood stash.log. Required package signatures are not skipped. Installation fetches core.db through the cache before the heavy Docker build; `python3 manage.py check-network` runs the same check manually. A cached core.db proves the local path only; use repair-stash --refresh-metadata before the check to test upstream networking.


## Workspace permission fix (2.4)

The original cap-drop=ALL setup prevented container root from writing to host-user-owned bind mounts. New projects add only DAC_OVERRIDE for filesystem permission checks and retain no-new-privileges. Main controller also gets this capability for its existing mounts. No host root filesystem/Docker socket is mounted.

Run `python3 manage.py repair-projects` after replacing companion files. Supported AVA project containers are recreated using their existing immutable image, environment, loopback ports, mounts, resources, KVM attachment and command, with DAC_OVERRIDE added. A workspace write check runs before success. The stopped old container is retained under a reported repair name to preserve any unmounted writable-layer data; failed replacement rolls back. Existing image bootstrap is repaired by the capability change without a complete Arch rebuild. Restarted processes/apps may need resuming.

New bootstrap checks workspace writability before starting services and logs stash to /tmp rather than requiring a workspace logfile. New project crash restart is limited to three attempts. Repair does not chmod 777, recursively change host ownership, or bypass read-only mounts/SELinux/user-namespace policies. Unsupported custom containers remain unchanged with a message.

## Hypervisor-style controls

The frontend now uses a blue/gray host console, project inventory rows with allocated CPU/RAM, and Actions menus for power on, shut down, restart, logs, resources, successor and retirement. Edit resources changes Docker CPU/memory limits; these are container allocations, not QEMU guest hardware changes. The backend is still Docker with Arch projects and optional QEMU/KVM, not VMware ESXi.

## Revision 2.5: local and hosted interface
The panel at http://127.0.0.1:8790 runs independently of Sites. Both editions ship from the same source in every companion release. New installs default to the local origin; existing hosted origin settings remain valid. Updating the hosted site does not automatically update your computer. Extract each companion update preserving .env, then run `python3 update-interface.py` to refresh the running panel and desktop viewer without rebuilding projects. Backend changes still require `manage.py stop` and `manage.py install`.

The VNC viewer defaults to fitting the existing desktop rather than requesting a display resize during handshake. It reports module, WebSocket and authentication failures visibly; Resize desktop remains opt-in. This addresses a possible black-screen path but a live host is needed to confirm the cause.

## Revision 2.6: local pairing
Both http://localhost:8790 and http://127.0.0.1:8790 are accepted exact local panel origins. Pair with RELAY_TOKEN, not CONTROL_DESKTOP_PASSWORD. Extract this update preserving .env, run `python3 manage.py stop` then `python3 manage.py install` to replace the running controller/proxy code. `update-interface.py` alone only refreshes the interface, not backend origin checks. Hosted origin remains allowed via SITE_ORIGIN.

## Revision 2.7: desktop diagnostics
Control Chromium now has explicit HOME/runtime/profile paths, a writable-profile check, a shared desktop D-Bus session, reduced shared-memory dependence, and separate startup logs. X server readiness is checked before launching desktop clients. The browser sandbox remains enabled. The custom viewer links to standard noVNC to distinguish viewer problems from VNC transport problems.

Run `python3 desktop-doctor.py` (or append a project name) to collect display geometry, disk space, permissions, process names, logs, and the VNC greeting without printing .env. These changes have not been verified on a live Docker desktop. Exact Chromium I/O errors are needed to identify the cause.

## Revision 2.8: noVNC launch buttons and Chromium namespace fix
Main-container noVNC buttons are in Host summary and the desktop controls. Every project with a published 6080/tcp port gets its own noVNC button using that project's actual localhost port. Non-desktop projects have no desktop button. These open the standard noVNC viewer, which includes fullscreen controls.

`ava-browser` launches Chromium with --no-sandbox and --disable-dev-shm-usage to accommodate the observed Operation not permitted namespace failure. The main desktop startup and XFCE default-browser helper use it. Chromium's browser sandbox is disabled; use this container instance for the local control panel and your host browser for general browsing. Docker container restrictions remain. Existing project images retain their old launch setup until replaced; updating the interface updates their noVNC links. No live Docker verification was available.

## CoDa 2.9: IDE live desktop and desktop session chooser
The IDE now exposes the previous live screenshot controls directly, with Load live desktop and noVNC for the selected container. Desktop ports are resolved from actual project mappings; main uses 6090. Hosted embedding may be blocked by browser local-network rules, so the separate noVNC button remains available.

VNC authentication is followed by a session chooser offering XFCE or Plasma (X11). This is desktop selection after the existing VNC password, not a new Linux user/password login. XFCE runs with explicit window manager, panel, desktop and icon theme, software rendering and compositing disabled. Plasma uses the separately packaged X11 session and software rendering. Desktop project process limits are raised to 512. Desktop logout returns to the chooser where supported; restarting the container always returns to it.

Extract preserving .env; run `python3 manage.py stop`, `python3 manage.py install`, `python3 update-interface.py`. Existing running desktop projects also need `python3 repair-desktops.py`, or append one project name. This performs a full Arch upgrade with the extra desktop packages through the configured local-first mirror, replaces only desktop/startup helpers, then restarts each project. Project data and mappings stay in place. Custom startup commands are skipped. Repair is not transactional if package installation fails: fix the download error and rerun. No live Docker/Plasma session was available for verification; screenshot evidence suggests an incomplete desktop but does not prove the precise cause.

The main control desktop's ava user has passwordless sudo inside that container. Its no-new-privileges flag is removed so sudo can switch to container root. Project and proxy restrictions remain; project CLI already runs as root. This does not grant host root. Docker Compose must recreate the main container through install for this configuration change to take effect.
