# AVA / Chord Projects · revision 2.1

Available implementation:
- Projects: create, successor staging, start/stop/restart, logs, retire.
- Host-local app and desktop TCP ports; persistent ~/Documents/avachord workspaces.
- Main Arch nest controller, scoped host Docker broker, provider relay.
- Root CLI without model keys, background apps, real project file explorer/editor/save, previews.
- Main Arch XFCE control desktop with local panel/IDE in Chromium; interactive project desktops.
- Fullscreen desktop viewer, fit-to-window and remote desktop resize; screenshot fullscreen.
- QEMU desktop tools and optional KVM /dev/kvm attachment.
- Install/update server TUI, custom icons, dependency setup, preserve-data uninstall, confirmed full erase.
- Shared local-first Arch/Python/Git/image/npm stash in Documents/avachord.
- Stream-through package downloads, atomic cache files, incremental SHA-256 receipts and incomplete-download repair.
- Self-contained ChatGPT/Gemini connection sidecar, bookmarklet and optional WebMCP root CLI.
- Sites MCP commands when the HTTPS broker endpoint and pairing token are connected.

Removed by request:
- Web traversal UI and proxy endpoint.
- Orphan inventory UI, scanner and MCP tool.

Validation:
- Broker authentication, project ports/root CLI/lifecycle and MCP routing checked with mock Docker/broker.
- ChatGPT/Gemini sidecar checked in a simulated DOM.
- Streaming cache tested over real localhost HTTP with controlled upstream download; initial bytes arrive before cache completion.
- This environment has no Docker/KVM/browser desktop. Arch builds and XFCE/Chromium sessions still require real host verification.
- No QEMU guest disk/ISO is bundled or booted.
- Local browser security restrictions can block HTTP embedding. Open app/full console are available.
- Direct root commands can bypass stash helpers; all-protocol egress enforcement is not claimed.
