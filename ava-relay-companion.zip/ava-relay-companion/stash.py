import pathlib,os,urllib.request,urllib.parse,urllib.error,hashlib,json,time,threading,uuid,socket,http.client,ssl,sys
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=pathlib.Path(os.getenv('AVACHORD_HOME',str(pathlib.Path.home()/'Documents/avachord')))/'stash';ROOT.mkdir(parents=True,exist_ok=True)
LOCKS={};guard=threading.Lock()
ADDRESS_FAMILY=os.getenv('STASH_ADDRESS_FAMILY','ipv4').lower()
def ipv4_connect(address,timeout=socket._GLOBAL_DEFAULT_TIMEOUT,source_address=None,**kwargs):
 host,port=address;last_error=None
 for family,kind,protocol,canonical,sockaddr in socket.getaddrinfo(host,port,socket.AF_INET,socket.SOCK_STREAM):
  sock=socket.socket(family,kind,protocol)
  try:
   if timeout is not socket._GLOBAL_DEFAULT_TIMEOUT:sock.settimeout(timeout)
   if source_address:sock.bind(source_address)
   sock.connect(sockaddr);return sock
  except OSError as e:last_error=e;sock.close()
 if last_error:raise last_error
 raise OSError('No IPv4 address available for '+str(host))
class IPv4HTTPSHandler(urllib.request.HTTPSHandler):
 def https_open(self,request):
  def connection(host,**kwargs):
   conn=http.client.HTTPSConnection(host,**kwargs);conn._create_connection=ipv4_connect;return conn
  return self.do_open(connection,request,context=ssl.create_default_context())
class IPv4HTTPHandler(urllib.request.HTTPHandler):
 def http_open(self,request):
  def connection(host,**kwargs):
   conn=http.client.HTTPConnection(host,**kwargs);conn._create_connection=ipv4_connect;return conn
  return self.do_open(connection,request)
class HTTPSOnlyRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,request,fp,code,msg,headers,newurl):
  if urllib.parse.urlparse(newurl).scheme!='https':raise urllib.error.URLError('Refusing non-HTTPS mirror redirect')
  return super().redirect_request(request,fp,code,msg,headers,newurl)
def open_url(url,timeout=180):
 if ADDRESS_FAMILY=='auto':return urllib.request.urlopen(url,timeout=timeout)
 return urllib.request.build_opener(IPv4HTTPHandler(),IPv4HTTPSHandler(),HTTPSOnlyRedirect()).open(url,timeout=timeout)
def upstream(relative):
 bases=['https://geo.mirror.pkgbuild.com/','https://mirrors.kernel.org/archlinux/']
 candidates=[base+urllib.parse.quote(relative,safe='/@:+') for base in bases]
 filename=relative.rsplit('/',1)[-1]
 if '.pkg.tar.' in filename:
  package=filename.split('.pkg.tar.',1)[0].rsplit('-',3)[0]
  if package:candidates.append('https://archive.archlinux.org/packages/'+package[0]+'/'+package+'/'+urllib.parse.quote(filename,safe='@:+'))
 failures=[];all_missing=True
 for url in candidates:
  for attempt in range(2):
   try:return open_url(url,timeout=180),url
   except urllib.error.HTTPError as e:
    failures.append({'url':url,'status':e.code,'error':str(e)})
    if e.code not in (404,410):all_missing=False
    if e.code in (404,410) or e.code<500:break
   except (urllib.error.URLError,TimeoutError,OSError) as e:all_missing=False;failures.append({'url':url,'error':str(e)})
 if not (all_missing and relative.endswith(('.db.sig','.files.sig'))):print('Stash upstream attempts: '+json.dumps({'path':relative,'address_family':ADDRESS_FAMILY,'attempts':failures}),flush=True)
 if all_missing:raise urllib.error.HTTPError(candidates[-1],404,'Not found on mirrors or archive',None,None)
 raise urllib.error.URLError('All upstream sources failed; see stash.log')
class Handler(BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def do_GET(self):
  path=urllib.parse.urlparse(self.path).path
  if path=='/status':
   data=json.dumps({'root':str(ROOT),'files':sum(1 for f in ROOT.rglob('*') if f.is_file()),'bytes':sum(f.stat().st_size for f in ROOT.rglob('*') if f.is_file()),'address_family':ADDRESS_FAMILY,'policy':'local first; cache misses stream while downloading'}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
  if not path.startswith('/arch/') or '..' in urllib.parse.unquote(path).split('/'):
   self.send_error(404);return
  relative=path[len('/arch/'):];target=ROOT/'arch'/relative;url='https://geo.mirror.pkgbuild.com/'+relative
  with guard:lock=LOCKS.setdefault(relative,threading.Lock())
  started=False;partial=None
  try:
   with lock:
    if target.exists():
     self.send_response(200);self.send_header('Content-Length',str(target.stat().st_size));self.end_headers();started=True
     with open(target,'rb') as source:
      while chunk:=source.read(65536):self.wfile.write(chunk)
     return
    target.parent.mkdir(parents=True,exist_ok=True);partial=target.with_name(target.name+'.'+uuid.uuid4().hex+'.partial')
    source,url=upstream(relative)
    with source,open(partial,'wb') as out:
     expected=source.headers.get('Content-Length');self.send_response(200)
     if expected:self.send_header('Content-Length',expected)
     else:self.send_header('Connection','close');self.close_connection=True
     self.end_headers();started=True;digest=hashlib.sha256();received=0;client_connected=True
     # read1 delivers available bytes rather than waiting to fill a large buffer.
     read=getattr(source,'read1',None) or source.read
     while chunk:=read(65536):
      out.write(chunk);digest.update(chunk);received+=len(chunk)
      if client_connected:
       try:self.wfile.write(chunk);self.wfile.flush()
       except (BrokenPipeError,ConnectionResetError):client_connected=False
     if expected and received!=int(expected):raise IOError('Truncated upstream package')
    os.replace(partial,target);partial=None
    receipt={'url':url,'time':time.time(),'bytes':received,'sha256':digest.hexdigest()};(ROOT/'receipts').mkdir(exist_ok=True);(ROOT/'receipts'/(hashlib.sha256(relative.encode()).hexdigest()+'.json')).write_text(json.dumps(receipt))
  except Exception as e:
   if not (relative.endswith(('.db.sig','.files.sig')) and isinstance(e,urllib.error.HTTPError) and e.code==404):print('Stash download failed:',relative,type(e).__name__,str(e),flush=True)
   if started:self.close_connection=True
   else:self.send_error(e.code if isinstance(e,urllib.error.HTTPError) and e.code in (404,410) else 502,'Upstream artifact unavailable; see stash.log')
  finally:
   if partial:partial.unlink(missing_ok=True)
if __name__=='__main__':
 print('AVA stash starting; address family='+ADDRESS_FAMILY,flush=True)
 ThreadingHTTPServer(('127.0.0.1',8791),Handler).serve_forever()
