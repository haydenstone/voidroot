#!/bin/bash
set -eu
export HOME=/home/ava
export DISPLAY=:2
export XDG_RUNTIME_DIR=/tmp/ava-runtime-$(id -u)
mkdir -p "$HOME/.vnc" "$HOME/.config/ava-chromium" "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR"
mkdir -p "$HOME/.local/share/xfce4/helpers" "$HOME/.config/xfce4"
cat > "$HOME/.local/share/xfce4/helpers/ava-chromium.desktop" <<'EOF'
[Desktop Entry]
Version=1.0
Type=X-XFCE-Helper
Name=AVA Chromium
Icon=chromium
X-XFCE-Category=WebBrowser
X-XFCE-Commands=/usr/local/bin/ava-browser
X-XFCE-CommandsWithParameter=/usr/local/bin/ava-browser "%s"
EOF
python - <<'PYCONFIG'
import configparser,pathlib
p=pathlib.Path.home()/'.config/xfce4/helpers.rc'
c=configparser.ConfigParser();c.optionxform=str
if p.exists():c.read(p)
if not c.has_section('Configuration'):c.add_section('Configuration')
c['Configuration']['WebBrowser']='ava-chromium'
with p.open('w') as f:c.write(f)
PYCONFIG
probe=$(mktemp "$HOME/.config/ava-chromium/.write-test.XXXXXX") || { echo 'Chromium profile is not writable' >&2; exit 78; }
rm -f "$probe"
printf '%s' "$CONTROL_DESKTOP_PASSWORD" | vncpasswd -f > "$HOME/.vnc/passwd"
chmod 600 "$HOME/.vnc/passwd"
Xvnc :2 -geometry 1440x900 -depth 24 -rfbport 5902 -rfbauth "$HOME/.vnc/passwd" -localhost yes >/tmp/ava-xvnc.log 2>&1 &
vnc_pid=$!
ready=0
for i in {1..50}; do
 kill -0 "$vnc_pid" 2>/dev/null || { cat /tmp/ava-xvnc.log >&2; exit 1; }
 if xdotool getdisplaygeometry >/dev/null 2>&1; then ready=1; break; fi
 sleep .2
done
[ "$ready" = 1 ] || { echo 'X desktop did not become ready' >&2; exit 1; }
websockify --web=/opt/novnc 127.0.0.1:6090 127.0.0.1:5902 >/tmp/ava-websockify.log 2>&1 &
CODA_OPEN_CONTROL=1 /bin/bash /opt/desktop-login.sh >/tmp/ava-xfce.log 2>&1 &
wait
