#!/usr/bin/env python3
import curses,subprocess,sys,pathlib,os,json,shutil
ROOT=pathlib.Path(__file__).resolve().parent
HOME=pathlib.Path(os.getenv('AVACHORD_HOME',str(pathlib.Path.home()/'Documents/avachord')))
ITEMS=[('◈','Install / update','install'),('⌁','Service status','status'),('▣','Projects','projects'),('▤','Service logs','logs'),('⬡','Stash status','stash-status'),('↻','Refresh stash','stash-update'),('■','Stop services','stop'),('◇','Uninstall · keep files','uninstall'),('⚠','Full uninstall / erase','purge')]
def ui(stdscr):
 try:curses.curs_set(0)
 except curses.error:pass
 stdscr.keypad(True)
 try:
  curses.start_color();curses.use_default_colors();curses.init_pair(1,curses.COLOR_CYAN,-1);curses.init_pair(2,curses.COLOR_BLACK,curses.COLOR_CYAN)
  accent=curses.color_pair(1);selected_color=curses.color_pair(2)
 except curses.error:accent=curses.A_BOLD;selected_color=curses.A_REVERSE
 selected=0
 def text(y,x,value,attr=0):
  h,w=stdscr.getmaxyx()
  if 0<=y<h and 0<=x<w:
   try:stdscr.addnstr(y,x,value,max(0,w-x-1),attr)
   except curses.error:pass
 while True:
  stdscr.erase();h,w=stdscr.getmaxyx()
  text(1,3,'◈  AVA / CHORD',accent|curses.A_BOLD);text(2,3,'ARCH PROJECT CONTROL STATION · REVISION 2')
  text(4,3,'LOCAL STORAGE  '+str(HOME),curses.A_DIM)
  cols=3 if w>=90 else 2 if w>=62 else 1;cell=max(26,(w-6)//cols)
  for i,(icon,label,command) in enumerate(ITEMS):
   y=6+(i//cols)*4;x=3+(i%cols)*cell;a=selected_color if i==selected else accent
   text(y,x,'┌'+'─'*(cell-3)+'┐',a);text(y+1,x,'│ '+icon+' '+label,a);text(y+2,x,'└'+'─'*(cell-3)+'┘',a)
  bottom=7+((len(ITEMS)+cols-1)//cols)*4
  text(bottom,3,'Docker '+('available' if shutil.which('docker') else 'missing')+'  ·  Git '+('available' if shutil.which('git') else 'missing')+'  ·  KVM '+('available' if pathlib.Path('/dev/kvm').exists() else 'unavailable'),curses.A_DIM)
  text(h-3,3,'↑ ↓ ← → select   Enter run   D dependencies   C doctor   Q quit',accent)
  if h<bottom+5:text(h-2,3,'Enlarge the terminal to show every panel.',curses.A_DIM)
  stdscr.refresh();key=stdscr.getch()
  if key in (ord('q'),ord('Q')):break
  if key==curses.KEY_RIGHT:selected=(selected+1)%len(ITEMS)
  elif key==curses.KEY_LEFT:selected=(selected-1)%len(ITEMS)
  elif key==curses.KEY_DOWN:selected=(selected+cols)%len(ITEMS)
  elif key==curses.KEY_UP:selected=(selected-cols)%len(ITEMS)
  elif key in (10,13,ord('c'),ord('C'),ord('d'),ord('D')):
   command='doctor' if key in (ord('c'),ord('C')) else 'dependencies' if key in (ord('d'),ord('D')) else ITEMS[selected][2]
   curses.def_prog_mode();curses.endwin()
   try:
    print('\n◈ AVA / CHORD · '+command+'\n')
    if command=='purge':
     print('This deletes all AVA project containers and files under '+str(HOME))
     if input('Type ERASE AVACHORD to continue: ')!='ERASE AVACHORD':print('Cancelled.')
     else:subprocess.run([sys.executable,str(ROOT/'manage.py'),'purge','--yes'],cwd=ROOT)
    else:subprocess.run([sys.executable,str(ROOT/'manage.py'),command],cwd=ROOT)
    input('\nPress Enter to return to the control station…')
   except (KeyboardInterrupt,EOFError):pass
   finally:curses.reset_prog_mode();stdscr.refresh()
if __name__=='__main__':
 if not sys.stdin.isatty():raise SystemExit('Run python3 tui.py in an interactive terminal.')
 curses.wrapper(ui)
