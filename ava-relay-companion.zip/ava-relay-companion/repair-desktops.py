#!/usr/bin/env python3
"""Upgrade desktop packages and startup in managed existing project containers."""
import json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
p=subprocess.run(['docker','ps','--filter','label=ava.project=true','--format','{{.Names}}'],capture_output=True,text=True,check=True)
names=p.stdout.splitlines()
if len(sys.argv)>1:
 if sys.argv[1] not in names:raise SystemExit('Choose a running AVA project container')
 names=[sys.argv[1]]
packages=['adwaita-icon-theme','librsvg','plasma-desktop','plasma-x11-session','kwin-x11','dolphin','konsole','breeze-icons','zenity']
for name in names:
 data=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
 if not any(e.startswith('DESKTOP_PASSWORD=') and e.split('=',1)[1] for e in data['Config'].get('Env',[])):continue
 if data['Config'].get('Cmd')!=['/bin/bash','/opt/bootstrap.sh']:
  print('Skipped custom startup:',name);continue
 print('Updating desktop packages:',name,flush=True)
 subprocess.run(['docker','exec','--user','0',name,'pacman','-Syu','--disable-download-timeout','--noconfirm',*packages],check=True)
 for file in ['bootstrap.sh','desktop-session.sh','desktop-login.sh','desktop.html']:
  dest='/opt/novnc/desktop.html' if file=='desktop.html' else '/opt/'+file
  subprocess.run(['docker','cp',str(root/file),name+':'+dest],check=True)
 subprocess.run(['docker','cp',str(root/'ava-browser'),name+':/usr/local/bin/ava-browser'],check=True)
 subprocess.run(['docker','exec','--user','0',name,'chmod','+x','/usr/local/bin/ava-browser'],check=True)
 limit=max(512,data['HostConfig'].get('PidsLimit') or 0)
 subprocess.run(['docker','update','--pids-limit',str(limit),name],check=True)
 subprocess.run(['docker','restart',name],check=True)
 print('Desktop repaired; reconnect and choose XFCE or Plasma:',name,flush=True)
print('Project files and port mappings were retained.')
