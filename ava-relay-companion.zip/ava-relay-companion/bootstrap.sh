#!/bin/bash
set -eu
mkdir -p /workspace
probe="$(mktemp /workspace/.ava-write-test.XXXXXX)" || { echo "AVA: /workspace is not writable; run manage.py repair-projects on the host." >&2; exit 78; }
rm -f "$probe"
python /opt/stash.py >/tmp/ava-stash.log 2>&1 &
if [ ! -e /workspace/index.html ]; then
cat > /workspace/index.html <<'HTML'
<!doctype html><html><meta charset="utf-8"><title>AVA Arch Project</title><body style="background:#101a23;color:#8be6db;font:18px system-ui;padding:48px"><h1>Arch project online</h1><p>Your container has bootstrapped successfully. Edit /workspace/index.html in the AVA browser IDE.</p></body></html>
HTML
fi
python -m http.server "${APP_PORT:-8080}" --bind 0.0.0.0 --directory /workspace >/workspace/app.log 2>&1 &
if [ -n "${DESKTOP_PASSWORD:-}" ]; then
mkdir -p /root/.vnc
printf '%s' "$DESKTOP_PASSWORD" | vncpasswd -f > /root/.vnc/passwd
chmod 600 /root/.vnc/passwd
Xvnc :1 -geometry 1440x900 -depth 24 -rfbport 5901 -rfbauth /root/.vnc/passwd -localhost yes >/workspace/desktop.log 2>&1 &
for i in {1..50}; do
DISPLAY=:1 xdotool getdisplaygeometry >/dev/null 2>&1 && break
sleep .2
done
DISPLAY=:1 xdotool getdisplaygeometry >/dev/null 2>&1 || { echo 'Project X desktop did not become ready' >&2; exit 1; }
DISPLAY=:1 /bin/bash /opt/desktop-login.sh >>/workspace/desktop.log 2>&1 &
websockify --web=/opt/novnc 6080 127.0.0.1:5901 >>/workspace/desktop.log 2>&1 &
fi
echo "Arch runtime ready; preview port ${APP_PORT:-8080}"
exec sleep infinity
