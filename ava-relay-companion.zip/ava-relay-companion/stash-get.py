import os
import pathlib,urllib.request,urllib.parse,hashlib,json,time,sys,ipaddress,socket
if len(sys.argv)!=2:raise SystemExit('python3 stash-get.py https://public-artifact-url')
url=sys.argv[1];u=urllib.parse.urlparse(url)
if u.scheme!='https' or not u.hostname or u.username or u.password:raise SystemExit('Public HTTPS URL required')
for addr in socket.getaddrinfo(u.hostname,443):
 if not ipaddress.ip_address(addr[4][0]).is_global:raise SystemExit('Private destinations rejected')
root=pathlib.Path(os.getenv('AVACHORD_HOME',str(pathlib.Path.home()/'Documents/avachord')))/'stash/artifacts';root.mkdir(parents=True,exist_ok=True);key=hashlib.sha256(url.encode()).hexdigest();target=root/key
if not target.exists():
 class NoRedirect(urllib.request.HTTPRedirectHandler):
  def redirect_request(self,*a,**kw):return None
 with urllib.request.build_opener(NoRedirect).open(url,timeout=60) as r,open(str(target)+'.partial','wb') as f:
  while chunk:=r.read(1024*1024):f.write(chunk)
 pathlib.Path(str(target)+'.partial').replace(target)
 target.with_suffix('.json').write_text(json.dumps({'url':url,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'downloaded':time.time()}))
print(target)
