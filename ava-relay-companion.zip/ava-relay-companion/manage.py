import pathlib,secrets,subprocess,sys,os,signal
root=pathlib.Path(__file__).resolve().parent
home=pathlib.Path(os.getenv('AVACHORD_HOME',str(pathlib.Path.home()/'Documents/avachord'))).resolve();home.mkdir(parents=True,exist_ok=True);os.environ['AVACHORD_HOME']=str(home)
if len(sys.argv)<2:
 subprocess.run([sys.executable,str(root/'tui.py')],check=True);raise SystemExit(0)
a=sys.argv[1];env=root/'.env'
if a=='dependencies':
 import shutil
 release=pathlib.Path('/etc/os-release').read_text();admin=[] if os.geteuid()==0 else ['sudo']
 if 'ID=arch' in release or 'ID="arch"' in release:cmd=admin+['pacman','-Syu','--needed','--noconfirm','docker','docker-compose','python','git']
 elif 'ID=ubuntu' in release or 'ID="ubuntu"' in release:
  subprocess.run(admin+['apt-get','update'],check=True);cmd=admin+['apt-get','install','-y','docker.io','docker-compose-v2','python3-venv','git']
 else:raise SystemExit('Automatic dependencies support Ubuntu and Arch. Install Docker Compose, Git and Python venv on this distribution, then run doctor.')
 subprocess.run(cmd,check=True);subprocess.run(admin+['systemctl','enable','--now','docker'],check=True)
 print('Dependencies installed. Confirm your user can run docker info before installation. This command does not alter user group membership.');raise SystemExit(0)
if a=='repair-stash':
 pidfile=root/'stash.pid'
 if pidfile.exists():
  pid=int(pidfile.read_text())
  try:
   cmdline=pathlib.Path('/proc/'+str(pid)+'/cmdline').read_bytes()
   if str(root/'stash.py').encode() not in cmdline:raise SystemExit('Stash PID belongs to another process; refusing to stop it.')
   os.kill(pid,signal.SIGTERM)
   import time
   for attempt in range(30):
    if not pathlib.Path('/proc/'+str(pid)).exists():break
    time.sleep(.1)
  except FileNotFoundError:pass
  pidfile.unlink(missing_ok=True)
 removed=0;metadata=0
 for f in (home/'stash/arch').rglob('*') if (home/'stash/arch').exists() else []:
  if f.is_file() and f.name.endswith(('.partial','.part')):f.unlink();removed+=1
  elif '--refresh-metadata' in sys.argv and f.is_file() and f.name.endswith(('.db','.db.sig','.files','.files.sig')):f.unlink();metadata+=1
 print('Stash stopped; removed '+str(removed)+' incomplete downloads; '+str(metadata)+' repository metadata files refreshed. Complete packages, mirrors, project files and .env retained. Run install to restart and retry.');raise SystemExit(0)
if a=='check-network':
 import urllib.request,json,time
 for attempt in range(30):
  try:
   response=urllib.request.urlopen('http://127.0.0.1:8791/status',timeout=2);status=json.load(response);break
  except Exception:
   if attempt==29:raise SystemExit('Stash is not running. Start install or inspect stash.log.')
   time.sleep(.1)
 try:
  with urllib.request.urlopen('http://127.0.0.1:8791/arch/core/os/x86_64/core.db',timeout=190) as response:
   # Fetch and retain metadata through the local cache, including connection preflight.
   data=response.read()
  print(json.dumps({'stash':status.get('address_family','old-version'),'core_db_bytes':len(data),'result':'local-cache / mirror request passed'},indent=2))
 except Exception as e:raise SystemExit('Mirror preflight failed: '+str(e)+'. Check stash.log; no Docker build started.')
 raise SystemExit(0)
if a=='repair-projects':
 subprocess.run([sys.executable,str(root/'repair-projects.py')],cwd=root,check=True);raise SystemExit(0)
if a=='projects':
 subprocess.run(['docker','ps','-a','--filter','label=ava.project=true'],check=True);raise SystemExit(0)
if a=='purge':
 if home==pathlib.Path.home() or home==pathlib.Path('/') or len(home.parts)<4:raise SystemExit('Refusing unsafe storage root')
 if '--yes' not in sys.argv:
  if input('Remove all AVA projects and erase '+str(home)+'? Type ERASE AVACHORD: ')!='ERASE AVACHORD':raise SystemExit('Cancelled.')
 subprocess.run([sys.executable,str(root/'manage.py'),'uninstall'],cwd=root,check=True)
 ids=subprocess.run(['docker','ps','-aq','--filter','label=ava.project=true'],capture_output=True,text=True,check=True).stdout.split()
 if ids:subprocess.run(['docker','rm','-f',*ids],check=True)
 subprocess.run(['docker','image','rm','ava-project-runtime:arch'],check=False)
 import shutil
 shutil.rmtree(home);print('Projects and avachord storage removed. Docker and host dependencies remain.');raise SystemExit(0)
if a=='doctor':
 import shutil,json
 print(json.dumps({'storage':str(home),'docker':bool(shutil.which('docker')),'git':bool(shutil.which('git')),'kvm':pathlib.Path('/dev/kvm').exists(),'python':sys.version,'platform':sys.platform},indent=2));raise SystemExit(0)
if a=='install':
 if not env.exists():env.write_text('RELAY_TOKEN='+secrets.token_urlsafe(32)+'\nCONTROL_DESKTOP_PASSWORD='+secrets.token_urlsafe(12)+'\nSITE_ORIGIN=http://127.0.0.1:8790\nOPENAI_API_KEY=\nGEMINI_API_KEY=\nANTHROPIC_API_KEY=\n');env.chmod(0o600)
 if 'REPLACE_WITH_SITE_ORIGIN' in env.read_text():env.write_text(env.read_text().replace('REPLACE_WITH_SITE_ORIGIN','http://127.0.0.1:8790'))
 stash_pid=root/'stash.pid'
 running=False
 if stash_pid.exists():
  try:os.kill(int(stash_pid.read_text()),0);running=True
  except ProcessLookupError:pass
 if not running:
  stash_process=subprocess.Popen([sys.executable,str(root/'stash.py')],stdout=open(root/'stash.log','a'),stderr=subprocess.STDOUT,start_new_session=True);stash_pid.write_text(str(stash_process.pid))
 subprocess.run([sys.executable,str(root/'manage.py'),'check-network'],cwd=root,check=True)
 subprocess.run([sys.executable,str(root/'stash-prepare.py')],cwd=root,check=True)
 build=subprocess.run(['docker','build','--network','host','-t','ava-project-runtime:arch','-f','Runtime.Dockerfile','.'],cwd=root)
 if build.returncode:raise SystemExit('Arch image build failed. Inspect stash.log for upstream HTTP details. Run stop, repair-stash --refresh-metadata, then install; cached packages and project files are preserved.')
 subprocess.run(['docker','save','-o',str(home/'stash/images/ava-project-runtime.tar'),'ava-project-runtime:arch'],cwd=root,check=True)
 if 'AVACHORD_HOME=' not in env.read_text():
  with env.open('a') as f:f.write('AVACHORD_HOME='+str(home)+'\n')
 cmd=['up','-d','--build']
elif a=='stash-status':
 import urllib.request
 print(urllib.request.urlopen('http://127.0.0.1:8791/status').read().decode());raise SystemExit(0)
elif a=='stash-update':
 repo=home/'stash/git/noVNC.git'
 if repo.exists():subprocess.run(['git','-C',str(repo),'fetch','--all','--prune'],check=True)
 for marker in ['stash/wheels.complete']:
  (home/marker).unlink(missing_ok=True)
 for f in (home/'stash/arch').rglob('*') if (home/'stash/arch').exists() else []:
  if f.is_file() and (f.name.endswith('.db') or f.name.endswith('.db.sig') or f.name.endswith('.files') or f.name.endswith('.files.sig')):f.unlink()
 print('Repository metadata invalidated; package archives remain. Next install refreshes metadata and wheels.');raise SystemExit(0)
elif a=='uninstall':cmd=['down','--rmi','local','--remove-orphans']
elif a=='stop':cmd=['stop']
elif a=='status':cmd=['ps']
elif a=='logs':cmd=['logs','--tail','100']
else:raise SystemExit('Unknown command')
subprocess.run(['docker','compose','-p','ava-relay',*cmd],cwd=root,check=True)

if a=='install':
 if (root/'broker.pid').exists():
  try:
   os.kill(int((root/'broker.pid').read_text()),0)
   raise SystemExit('Broker already running. Use stop before restarting.')
  except ProcessLookupError:pass
 values=dict(line.split('=',1) for line in env.read_text().splitlines() if '=' in line and not line.startswith('#'))
 process=subprocess.Popen([sys.executable,str(root/'service.py')],env={**os.environ,**values,'ROLE':'agent'},stdout=open(root/'broker.log','a'),stderr=subprocess.STDOUT,start_new_session=True)
 (root/'broker.pid').write_text(str(process.pid))
 print('Broker running on 127.0.0.1:8788; pair using RELAY_TOKEN in .env')
if a in ('stop','uninstall') and (root/'broker.pid').exists():
 try:os.kill(int((root/'broker.pid').read_text()),signal.SIGTERM)
 except ProcessLookupError:pass
 (root/'broker.pid').unlink()

if a in ('stop','uninstall') and (root/'stash.pid').exists():
 try:os.kill(int((root/'stash.pid').read_text()),signal.SIGTERM)
 except ProcessLookupError:pass
 (root/'stash.pid').unlink()
