import pathlib,os,subprocess,json,re,uuid
HOME=pathlib.Path(os.getenv('AVACHORD_HOME',str(pathlib.Path.home()/'Documents/avachord'))).resolve()
def docker(args,check=True):
 p=subprocess.run(['docker',*args],capture_output=True,text=True)
 if check and p.returncode:raise RuntimeError(p.stderr.strip())
 return p
ids=docker(['ps','-aq','--filter','label=ava.project=true']).stdout.split()
if not ids:raise SystemExit('No AVA projects found. New deployments include the permission fix.')
failures=[]
for identity in ids:
 data=json.loads(docker(['inspect',identity]).stdout)[0];config=data['Config'];host=data['HostConfig'];name=data['Name'].lstrip('/')
 try:
  if re.search(r'-repair-[a-f0-9]{6}$',name):print(name+': retained repair backup; skipped');continue
  if not re.fullmatch(r'ava-project-[a-z0-9-]{1,40}',name) or config['Image']!='ava-project-runtime:arch':raise ValueError('Unsupported project identity/image; left unchanged')
  caps=host.get('CapAdd') or []
  if any(c.lower().removeprefix('cap_')=='dac_override' for c in caps):print(name+': already repaired');continue
  cmd=['run','-d','--name',name,'--cap-drop=ALL','--cap-add=DAC_OVERRIDE','--security-opt','no-new-privileges:true','--restart','on-failure:3','--user',config.get('User') or '0']
  for k,v in (config.get('Labels') or {}).items():cmd+=['--label',k+'='+v]
  for value in config.get('Env') or []:cmd+=['--env',value]
  for target,bindings in (host.get('PortBindings') or {}).items():
   for binding in bindings or []:
    if binding.get('HostIp')!='127.0.0.1' or not str(binding.get('HostPort','')).isdigit():raise ValueError('Non-loopback/automatic port mapping; left unchanged')
    cmd+=['--publish','127.0.0.1:'+binding['HostPort']+':'+target]
  for mount in data.get('Mounts',[]):
   if mount['Destination'] not in ('/workspace','/avachord/stash'):raise ValueError('Unexpected mount; left unchanged')
   if mount['Type']=='bind':
    source=pathlib.Path(mount['Source']).resolve()
    if HOME not in source.parents:raise ValueError('Bind source outside avachord; left unchanged')
    specification='type=bind,src='+str(source)+',dst='+mount['Destination']
   elif mount['Type']=='volume':specification='type=volume,src='+mount['Name']+',dst='+mount['Destination']
   else:raise ValueError('Unsupported storage; left unchanged')
   if not mount.get('RW',True):specification+=',readonly'
   cmd+=['--mount',specification]
  if host.get('Memory'):cmd+=['--memory',str(host['Memory'])]
  if host.get('NanoCpus'):cmd+=['--cpus',str(host['NanoCpus']/1e9)]
  if host.get('PidsLimit',0)>0:cmd+=['--pids-limit',str(host['PidsLimit'])]
  if host.get('ShmSize'):cmd+=['--shm-size',str(host['ShmSize'])]
  for device in host.get('Devices') or []:
   if device['PathOnHost']!='/dev/kvm':raise ValueError('Unexpected device; left unchanged')
   cmd+=['--device','/dev/kvm:/dev/kvm']
  if config.get('WorkingDir'):cmd+=['--workdir',config['WorkingDir']]
  # Reuse the original immutable image. Capability changes alone fix existing bootstrap copies.
  if config.get('Entrypoint'):cmd+=['--entrypoint',config['Entrypoint'][0]]
  cmd+=[data['Image']]+((config.get('Entrypoint') or [])[1:])+(config.get('Cmd') or [])
  backup=name+'-repair-'+uuid.uuid4().hex[:6];running=data['State']['Running'];docker(['stop',name]);docker(['rename',name,backup])
  try:
   docker(cmd)
   p=docker(['exec',name,'sh','-lc','f=$(mktemp /workspace/.ava-repair.XXXXXX) && rm -f "$f"'],check=False)
   if p.returncode:raise RuntimeError('Workspace write check failed: '+p.stderr.strip())
   # Retain the stopped old container so its unmounted writable layer is recoverable.
   print(name+': repaired; workspace/ports retained. Stopped backup: '+backup)
  except Exception:
   docker(['rm','-f',name],check=False);docker(['rename',backup,name])
   if running:docker(['start',name])
   raise
 except Exception as e:failures.append(name+': '+str(e));print(failures[-1])
if failures:raise SystemExit('Some projects were left unchanged or rolled back. Review messages above.')
