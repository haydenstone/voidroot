import os,json,time,subprocess,urllib.request,urllib.parse,socket,ipaddress,re,hmac
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
HOME=__import__('pathlib').Path(os.getenv('AVACHORD_HOME',str(__import__('pathlib').Path.home()/'Documents/avachord')));
ROLE=os.getenv('ROLE','agent'); TOKEN=os.environ['RELAY_TOKEN']; ORIGIN=os.environ['SITE_ORIGIN']; LOG=[]
def managed(name):
 if not isinstance(name,str) or not re.fullmatch(r'ava-(?:project|womb)-[a-z0-9-]{1,40}',name):raise ValueError('Invalid project name')
 if run(['docker','inspect','--format','{{index .Config.Labels "ava.project"}}',name])!='true' and run(['docker','inspect','--format','{{index .Config.Labels "ava.womb"}}',name])!='true':raise ValueError('Container is outside AVA management')
 return name
def desktop_target(name):
 if name=='ava-relay-nest-1' and run(['docker','inspect','--format','{{index .Config.Labels "ava.control"}}',name])=='true':return name
 return managed(name)
def port(value):
 if isinstance(value,bool) or not str(value).isdigit() or not 1024<=int(value)<=65535:raise ValueError('Ports must be integers from 1024 to 65535')
 return int(value)
def run(cmd):
 try:return subprocess.run(cmd,capture_output=True,text=True,timeout=5).stdout.strip()
 except Exception as e:return str(e)
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def send(self,code,obj):
  data=json.dumps(obj).encode();self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Access-Control-Allow-Origin',self.headers.get('Origin') if self.headers.get('Origin') in (ORIGIN,'http://127.0.0.1:8790','http://localhost:8790','https://chatgpt.com','https://gemini.google.com') else ORIGIN);self.send_header('Access-Control-Allow-Private-Network','true');self.end_headers();self.wfile.write(data)
 def do_OPTIONS(self):
  self.send_response(204);self.send_header('Access-Control-Allow-Origin',self.headers.get('Origin') if self.headers.get('Origin') in (ORIGIN,'http://127.0.0.1:8790','http://localhost:8790','https://chatgpt.com','https://gemini.google.com') else ORIGIN);self.send_header('Access-Control-Allow-Headers','Authorization,Content-Type');self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS');self.send_header('Access-Control-Allow-Private-Network','true');self.end_headers()
 def do_GET(self):self.handle_api(False)
 def do_POST(self):self.handle_api(True)
 def handle_api(self,post):
  if self.headers.get('Origin') not in (None,ORIGIN,'http://127.0.0.1:8790','http://localhost:8790','https://chatgpt.com','https://gemini.google.com'):return self.send(403,{'error':'Origin rejected'})
  if not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+TOKEN):return self.send(401,{'error':'Pairing token required'})
  try:
   size=int(self.headers.get('Content-Length',0))
   if size>65536:raise ValueError('Request too large')
   body=json.loads(self.rfile.read(size) or b'{}') if post else {}
   if ROLE=='manager':
    if self.path not in ('/health','/telemetry','/containers','/deploy','/remove','/shell','/start-app','/agent-run','/files','/desktop','/lifecycle','/logs','/stash','/resources'):return self.send(404,{'error':'Unknown management operation'})
    req=urllib.request.Request('http://127.0.0.1:8788'+self.path,data=json.dumps(body).encode() if post else None,headers={'Authorization':'Bearer '+TOKEN,'Content-Type':'application/json'})
    try:
     with urllib.request.urlopen(req,timeout=650) as r:return self.send(r.status,json.load(r))
    except urllib.error.HTTPError as e:return self.send(e.code,json.load(e))
   if self.path=='/health':out={'role':ROLE,'kvm_available':os.path.exists('/dev/kvm'),'time':time.time(),'uid':os.getuid(),'providers':{p:bool(os.getenv(p+'_API_KEY')) for p in ['OPENAI','GEMINI','ANTHROPIC']}}
   elif self.path=='/stash' and ROLE=='agent':
    with urllib.request.urlopen('http://127.0.0.1:8791/status',timeout=10) as response:out=json.load(response)
   elif self.path=='/telemetry' and ROLE=='agent':out={'hostname':socket.gethostname(),'load':os.getloadavg(),'interfaces':run(['ip','-j','address']),'routes':run(['ip','-j','route']),'neighbors':run(['ip','-j','neigh']),'memory':open('/proc/meminfo').read(),'scope':'Local broker host network; Docker containers isolated','events':LOG[-30:]}
   elif self.path=='/agent-run' and post and ROLE=='agent':
    name=managed(body['container'])
    history='You are Ava, a container engineer. You have root shell access only in '+name+'. Complete this task: '+body['task']+'. Respond ONLY with JSON: {"command":"shell command"} or {"done":"summary"}. Execute one command each turn. No markdown.'
    steps=[]
    for step in range(5):
     payload={'provider':body['provider'],'model':body['model'],'message':history}
     request=urllib.request.Request('http://127.0.0.1:8787/chat',data=json.dumps(payload).encode(),headers={'Authorization':'Bearer '+TOKEN,'Content-Type':'application/json'})
     with urllib.request.urlopen(request,timeout=100) as response:reply=json.load(response)
     provider=body['provider']
     if provider=='openai':answer=''.join(c.get('text','') for o in reply.get('output',[]) for c in o.get('content',[]) if c.get('type')=='output_text')
     elif provider=='gemini':answer=''.join(p.get('text','') for c in reply.get('candidates',[]) for p in c.get('content',{}).get('parts',[]))
     elif provider=='anthropic':answer=''.join(c.get('text','') for c in reply.get('content',[]))
     else:answer=reply.get('message',{}).get('content','')
     decision=json.loads(answer.strip().removeprefix('```json').removeprefix('```').removesuffix('```').strip())
     if 'done' in decision:steps.append({'done':decision['done']});break
     command=decision['command']
     p=subprocess.run(['docker','exec','--user','0',name,'/bin/sh','-lc',command],capture_output=True,text=True,timeout=30)
     result={'command':command,'output':(p.stdout+p.stderr)[-12000:],'exit_code':p.returncode};steps.append(result);LOG.append({'time':time.time(),'action':'agent command','container':name,'command':command,'exit':p.returncode})
     history+='\nYour command result: '+json.dumps(result)+'\nReturn the next JSON action.'
    out={'container':name,'steps':steps,'limit':5}
   elif self.path=='/containers' and ROLE=='agent':
    rows=[]
    p=subprocess.run(['docker','ps','-a','--filter','label=ava.project=true','--format','{{json .}}'],capture_output=True,text=True,timeout=10)
    if p.returncode:raise ValueError(p.stderr)
    for line in p.stdout.splitlines():
     row=json.loads(line);bindings=run(['docker','inspect','--format','{{json .NetworkSettings.Ports}}',row['Names']]);row['PublishedPorts']=json.loads(bindings or '{}') or {};limits=json.loads(run(['docker','inspect','--format','{{json .HostConfig}}',row['Names']]) or '{}');row['ResourceLimits']={'memory_mb':round(limits.get('Memory',0)/1048576),'cpus':limits.get('NanoCpus',0)/1e9};rows.append(row)
    out={'containers':'\n'.join(json.dumps(row) for row in rows)}
   elif self.path=='/deploy' and post and ROLE=='agent':
    import re
    name=body.get('name','')
    if not re.fullmatch(r'ava-project-[a-z0-9-]{1,40}',name):raise ValueError('Use ava-project- followed by lowercase letters, digits or hyphens')
    host=port(body.get('host_port',8080));internal=port(body.get('container_port',8080))
    if host in (5902,6090,8787,8788,8789,8790,8791):raise ValueError('Port reserved for AVA services')
    import uuid,hashlib
    project_uuid=str(uuid.uuid4());created=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()
    workspace=HOME/'projects'/name/'workspace';workspace.mkdir(parents=True,exist_ok=True);stash=HOME/'stash';stash.mkdir(parents=True,exist_ok=True)
    cmd=['docker','run','-d','-p',f'127.0.0.1:{host}:{internal}/tcp','-e',f'APP_PORT={internal}','--name',name,'--label','ava.project=true','--label','ava.nest=main','--label','ava.uuid='+project_uuid,'--label','ava.parent=ava-relay-nest-1','--mount',f'type=bind,src={workspace},dst=/workspace','--mount',f'type=bind,src={stash},dst=/avachord/stash','--cap-drop=ALL','--cap-add=DAC_OVERRIDE','--security-opt','no-new-privileges:true','--memory','512m','--cpus','1','--pids-limit','128','--restart','on-failure:3','ava-project-runtime:arch']
    desktop=body.get('desktop',False)
    if desktop:
     desktop_port=port(body.get('desktop_port',8081));password=body.get('desktop_password','')
     if desktop_port in (host,5902,6090,8787,8788,8789,8790,8791) or not isinstance(password,str) or len(password)<8:raise ValueError('Choose a separate desktop port and password of at least 8 characters')
     cmd[3:3]=['-p',f'127.0.0.1:{desktop_port}:6080/tcp','-e','DESKTOP_PASSWORD='+password,'--shm-size','256m']
    if body.get('kvm'):
     if not os.path.exists('/dev/kvm'):raise ValueError('KVM requested but /dev/kvm is unavailable on this host')
     cmd[3:3]=['--device','/dev/kvm:/dev/kvm']
    # Desktop and VM workloads require more memory than small app projects.
    if desktop or body.get('kvm'):cmd[cmd.index('--memory')+1]='4g';cmd[cmd.index('--cpus')+1]='2';cmd[cmd.index('--pids-limit')+1]='512'
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
    if p.returncode:raise ValueError(p.stderr)
    keypath=HOME/'control/signing.key';keypath.parent.mkdir(parents=True,exist_ok=True)
    if not keypath.exists():keypath.write_bytes(os.urandom(32));keypath.chmod(0o600)
    payload={'uuid':project_uuid,'name':name,'created':created,'parent':'ava-relay-nest-1','container_id':p.stdout.strip()}
    signature=hmac.new(keypath.read_bytes(),json.dumps(payload,sort_keys=True,separators=(',',':')).encode(),hashlib.sha256).hexdigest()
    (workspace.parent/'manifest.json').write_text(json.dumps({**payload,'payload':payload,'signature':signature},indent=2))
    out={'container':name,'uuid':project_uuid,'id':p.stdout.strip(),'url':f'http://127.0.0.1:{host}','host_port':host,'container_port':internal};LOG.append({'time':time.time(),'action':'deploy','container':name})
   elif self.path=='/resources' and post and ROLE=='agent':
    name=managed(body['container']);memory=int(body.get('memory_mb',0));cpus=float(body.get('cpus',0))
    if not 128<=memory<=65536 or not .25<=cpus<=32:raise ValueError('Memory must be 128–65536 MB; CPUs .25–32')
    p=subprocess.run(['docker','update','--memory',str(memory)+'m','--memory-swap',str(memory*2)+'m','--cpus',str(cpus),name],capture_output=True,text=True,timeout=15)
    if p.returncode:raise ValueError(p.stderr)
    out={'container':name,'memory_mb':memory,'cpus':cpus};LOG.append({'time':time.time(),'action':'update resources','container':name})
   elif self.path=='/lifecycle' and post and ROLE=='agent':
    name=managed(body['container']);operation=body.get('operation')
    if operation not in ('start','stop','restart'):raise ValueError('Invalid lifecycle operation')
    p=subprocess.run(['docker',operation,name],capture_output=True,text=True,timeout=30)
    if p.returncode:raise ValueError(p.stderr)
    out={'container':name,'operation':operation,'ok':True};LOG.append({'time':time.time(),'action':operation,'container':name})
   elif self.path=='/logs' and post and ROLE=='agent':
    name=managed(body['container']);p=subprocess.run(['docker','logs','--tail','150',name],capture_output=True,text=True,timeout=10);out={'output':(p.stdout+p.stderr)[-50000:]}
   elif self.path=='/desktop' and post and ROLE=='agent':
    name=desktop_target(body['container']);action=body.get('action')
    display=':2' if name=='ava-relay-nest-1' else ':1'
    prefix=['docker','exec','--user','ava' if display==':2' else '0','-e','DISPLAY='+display,name]
    if action=='screenshot':
     import base64
     p=subprocess.run(prefix+['import','-window','root','png:-'],capture_output=True,timeout=15)
     if p.returncode:raise ValueError(p.stderr.decode(errors='replace')[-3000:])
     out={'mimeType':'image/png','data':base64.b64encode(p.stdout).decode()}
    else:
     if action=='click':
      x=int(body['x']);y=int(body['y'])
      geometry=subprocess.run(prefix+['xdotool','getdisplaygeometry'],capture_output=True,text=True,timeout=5)
      if geometry.returncode:raise ValueError('Desktop geometry unavailable')
      width,height=map(int,geometry.stdout.split())
      if not 0<=x<width or not 0<=y<height:raise ValueError('Click outside desktop')
      args=['mousemove',str(x),str(y),'click','1']
     elif action=='type':args=['type','--clearmodifiers','--',str(body.get('text',''))[:16000]]
     elif action=='key':
      key=str(body.get('key',''))
      if not re.fullmatch(r'[A-Za-z0-9_+ -]{1,80}',key):raise ValueError('Invalid key sequence')
      args=['key','--clearmodifiers',key]
     else:raise ValueError('Unknown desktop action')
     p=subprocess.run(prefix+['xdotool']+args,capture_output=True,text=True,timeout=15)
     if p.returncode:raise ValueError(p.stderr[-3000:])
     out={'container':name,'action':action,'ok':True}
    LOG.append({'time':time.time(),'action':'desktop '+action,'container':name})
   elif self.path=='/files' and post and ROLE=='agent':
    name=managed(body['container']);action=body.get('action');path=body.get('path','/workspace')
    if action not in ('list','read','write'):raise ValueError('Unknown file operation')
    script="""import pathlib,json,sys
b=json.loads(sys.argv[1]);p=pathlib.Path(b.get('path','/workspace')).resolve();root=pathlib.Path('/workspace')
if p!=root and root not in p.parents:raise ValueError('Path is outside /workspace')
a=b['action']
if a=='list':out={'entries':[{'name':x.name,'path':str(x),'directory':x.is_dir()} for x in sorted(p.iterdir(),key=lambda x:(not x.is_dir(),x.name))][:500]}
elif a=='read':
 if p.stat().st_size>500000:raise ValueError('File exceeds editor size limit')
 out={'path':str(p),'content':p.read_text()}
else:
 text=b.get('content','')
 if len(text.encode())>500000:raise ValueError('File exceeds editor size limit')
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);out={'path':str(p),'saved':True}
print(json.dumps(out))
"""
    p=subprocess.run(['docker','exec','--user','0',name,'python','-c',script,json.dumps(body)],capture_output=True,text=True,timeout=15)
    if p.returncode:raise ValueError(p.stderr[-3000:])
    out=json.loads(p.stdout);LOG.append({'time':time.time(),'action':'file '+action,'container':name,'path':path})
   elif self.path=='/start-app' and post and ROLE=='agent':
    name=managed(body['container']);command=body.get('command','')
    if not isinstance(command,str) or not command.strip() or len(command)>16000:raise ValueError('App command required')
    p=subprocess.run(['docker','exec','-d','--user','0',name,'/bin/sh','-lc',command],capture_output=True,text=True,timeout=10)
    if p.returncode:raise ValueError(p.stderr)
    out={'container':name,'started':True,'note':'Process launched; app readiness is not yet verified'};LOG.append({'time':time.time(),'action':'start app','container':name,'command':command})
   elif self.path=='/remove' and post and ROLE=='agent':
    name=managed(body['container'])
    p=subprocess.run(['docker','rm','-f',name],capture_output=True,text=True,timeout=20);out={'output':p.stdout+p.stderr,'exit_code':p.returncode};LOG.append({'time':time.time(),'action':'remove','container':name})
   elif self.path=='/shell' and post and ROLE=='agent':
    name=managed(body['container'])
    cmd=body.get('command','');p=subprocess.run(['docker','exec','--user','0',name,'/bin/sh','-lc',cmd],capture_output=True,text=True,timeout=30);out={'output':(p.stdout+p.stderr)[-50000:],'exit_code':p.returncode};LOG.append({'time':time.time(),'action':'container shell','exit':p.returncode})
   elif self.path=='/chat' and post and ROLE=='proxy':
    provider=body['provider'];model=body['model'];message=body['message'];headers={'Content-Type':'application/json'}
    if provider=='openai':
     url='https://api.openai.com/v1/responses';headers['Authorization']='Bearer '+os.environ['OPENAI_API_KEY'];data={'model':model,'input':message}
    elif provider=='gemini':
     url='https://generativelanguage.googleapis.com/v1beta/models/'+urllib.parse.quote(model,safe='')+':generateContent';headers['x-goog-api-key']=os.environ['GEMINI_API_KEY'];data={'contents':[{'parts':[{'text':message}]}]}
    elif provider=='anthropic':
     url='https://api.anthropic.com/v1/messages';headers.update({'x-api-key':os.environ['ANTHROPIC_API_KEY'],'anthropic-version':'2023-06-01'});data={'model':model,'max_tokens':1024,'messages':[{'role':'user','content':message}]}
    elif provider=='ollama':url=os.getenv('OLLAMA_URL','http://host.docker.internal:11434')+'/api/chat';data={'model':model,'stream':False,'messages':[{'role':'user','content':message}]}
    else:raise ValueError('Unknown provider')
    with urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(data).encode(),headers=headers),timeout=90) as r:out=json.load(r)
   else:return self.send(404,{'error':'Endpoint unavailable'})
   self.send(200,out)
  except Exception as e:self.send(400,{'error':str(e)})
ThreadingHTTPServer(('0.0.0.0' if ROLE=='proxy' else '127.0.0.1',8788 if ROLE=='agent' else 8789 if ROLE=='manager' else 8787),Handler).serve_forever()
