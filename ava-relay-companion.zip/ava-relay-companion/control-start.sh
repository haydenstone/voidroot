#!/bin/bash
set -eu
if [ "${ROLE:-}" = manager ]; then
 python -m http.server 8790 --bind 127.0.0.1 --directory /opt/panel >/tmp/control-panel.log 2>&1 &
 if [ -n "${CONTROL_DESKTOP_PASSWORD:-}" ]; then
  runuser -u ava -- /bin/bash /opt/control-desktop.sh >/tmp/control-desktop.log 2>&1 &
 fi
fi
exec python /opt/service.py
