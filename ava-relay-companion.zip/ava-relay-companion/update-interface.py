#!/usr/bin/env python3
"""Refresh local panel and noVNC viewer without replacing project containers."""
import pathlib, subprocess
root=pathlib.Path(__file__).resolve().parent
p=subprocess.run(['docker','ps','--format','{{.Names}}','--filter','label=ava.project=true'],capture_output=True,text=True,check=True)
names=['ava-relay-nest-1']+p.stdout.splitlines()
for name in dict.fromkeys(names):
 if name!='ava-relay-nest-1' and not name.startswith('ava-project-'):continue
 check=subprocess.run(['docker','inspect','--format','{{.State.Running}}',name],capture_output=True,text=True)
 if check.returncode or check.stdout.strip()!='true':continue
 result=subprocess.run(['docker','cp',str(root/'desktop.html'),name+':/opt/novnc/desktop.html'])
 if result.returncode:raise SystemExit('Viewer update failed for '+name)
 if name=='ava-relay-nest-1':subprocess.run(['docker','cp',str(root/'panel')+'/.',name+':/opt/panel/'],check=True)
 print('Updated interface: '+name)
print('Reload the local panel and desktop with Ctrl+Shift+R. Project files were untouched.')
