#!/bin/bash
set -eu
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/coda-runtime-$(id -u)}"
export GSK_RENDERER=cairo LIBGL_ALWAYS_SOFTWARE=1 GDK_BACKEND=x11
mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR"
while true; do
 selection=$(dbus-run-session -- zenity --list --radiolist --title="CoDa · Desktop session" --text="VNC authenticated. Choose your desktop for this container." --width=540 --height=280 --column="Select" --column="Desktop" TRUE "XFCE" FALSE "Plasma (X11)" --ok-label="Start desktop" --cancel-label="Stay on login screen") || continue
 case "$selection" in
  XFCE) desktop=xfce;;
  'Plasma (X11)') desktop=plasma;;
  *) continue;;
 esac
 dbus-run-session -- /bin/bash /opt/desktop-session.sh "$desktop" || echo "Desktop exited with an error; inspect /tmp/coda-*.log" >&2
 done
