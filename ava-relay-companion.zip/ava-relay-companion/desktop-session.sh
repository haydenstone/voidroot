#!/bin/bash
set -eu
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/coda-runtime-$(id -u)}"
export GSK_RENDERER=cairo
export LIBGL_ALWAYS_SOFTWARE=1
export GDK_BACKEND=x11
cleanup(){ jobs -pr | xargs -r kill 2>/dev/null || true; }
trap cleanup EXIT TERM INT
if [ "${1:-xfce}" = plasma ]; then
 export QT_QUICK_BACKEND=software QT_QPA_PLATFORM=xcb QT_X11_NO_MITSHM=1 KWIN_COMPOSE=N
 mkdir -p "$HOME/.config"
 kwriteconfig6 --file startkderc --group General --key systemdBoot false
 if [ "${CODA_OPEN_CONTROL:-0}" = 1 ]; then
  /usr/local/bin/ava-browser http://127.0.0.1:8790/#ide >/tmp/ava-chromium.log 2>&1 &
 fi
 startplasma-x11 >/tmp/coda-plasma.log 2>&1 &
 wait "$!"
 exit
fi
mkdir -p "$XDG_RUNTIME_DIR" "$HOME/.config/xfce4/xfconf/xfce-perchannel-xml"
chmod 700 "$XDG_RUNTIME_DIR"
xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s false
xfconf-query -c xsettings -p /Net/IconThemeName -n -t string -s Adwaita
xfconf-query -c xsettings -p /Net/ThemeName -n -t string -s Adwaita
# Supply a panel on first boot without replacing an existing user's panel.
panel="$HOME/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml"
if [ ! -f "$panel" ]; then
cat > "$panel" <<'PANEL'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-panel" version="1.0"><property name="configver" type="int" value="2"/><property name="panels" type="array"><value type="int" value="1"/><property name="panel-1" type="empty"><property name="position" type="string" value="p=6;x=0;y=0"/><property name="position-locked" type="bool" value="true"/><property name="length" type="uint" value="100"/><property name="size" type="uint" value="36"/><property name="plugin-ids" type="array"><value type="int" value="1"/><value type="int" value="2"/><value type="int" value="3"/></property></property></property><property name="plugins" type="empty"><property name="plugin-1" type="string" value="applicationsmenu"/><property name="plugin-2" type="string" value="tasklist"/><property name="plugin-3" type="string" value="clock"/></property></channel>
PANEL
fi
xfsettingsd >/tmp/coda-settings.log 2>&1 &
xfwm4 --replace --compositor=off >/tmp/coda-window-manager.log 2>&1 &
wm=$!
xfdesktop >/tmp/coda-desktop.log 2>&1 &
xfce4-panel >/tmp/coda-panel.log 2>&1 &
# Use a visible solid backdrop rather than an absent wallpaper file.
for prefix in /backdrop/screen0/monitorVNC-0/workspace0 /backdrop/screen0/monitor0/workspace0; do
 xfconf-query -c xfce4-desktop -p "$prefix/image-style" -n -t int -s 0
 xfconf-query -c xfce4-desktop -p "$prefix/color-style" -n -t int -s 0
 xfconf-query -c xfce4-desktop -p "$prefix/rgba1" -n -a -t double -s .10 -t double -s .17 -t double -s .23 -t double -s 1
 done
if [ "${CODA_OPEN_CONTROL:-0}" = 1 ]; then
 /usr/local/bin/ava-browser http://127.0.0.1:8790/#ide >/tmp/ava-chromium.log 2>&1 &
fi
wait "$wm"
