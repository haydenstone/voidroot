#!/usr/bin/env python3
"""Collect desktop health without printing environment variables or passwords."""
import subprocess,sys,re
name=sys.argv[1] if len(sys.argv)>1 else 'ava-relay-nest-1'
if name!='ava-relay-nest-1' and not re.fullmatch(r'ava-project-[a-z0-9-]{1,40}',name):raise SystemExit('Invalid project name')
label='ava.control' if name=='ava-relay-nest-1' else 'ava.project'
p=subprocess.run(['docker','inspect','--format','{{index .Config.Labels "'+label+'"}}',name],capture_output=True,text=True,check=True)
if p.stdout.strip()!='true':raise SystemExit('Not an AVA managed container')
control=name=='ava-relay-nest-1'
display=':2' if control else ':1'
user='ava' if control else '0'
for title,args in [
 ('X desktop',['xdotool','getdisplaygeometry']),
 ('Disk and shared memory',['df','-h','/home/ava','/tmp','/dev/shm']),
 ('Profile permissions',['ls','-ld','/home/ava','/home/ava/.config','/home/ava/.config/ava-chromium']),
 ('Desktop processes',['ps','-eo','pid,comm']),
 ('Desktop logs',['sh','-c','for f in /tmp/ava-xvnc.log /tmp/ava-websockify.log /tmp/ava-xfce.log /tmp/ava-chromium.log /tmp/coda-settings.log /tmp/coda-window-manager.log /tmp/coda-desktop.log /tmp/coda-panel.log /tmp/coda-plasma.log /tmp/control-desktop.log /workspace/desktop.log; do if [ -f "$f" ]; then echo "$f"; tail -n 35 "$f"; fi; done'])]:
 print('\n'+title,flush=True)
 subprocess.run(['docker','exec','--user',user,'-e','DISPLAY='+display,name,*args])
port=5902 if control else 5901
print('\nVNC protocol greeting',flush=True)
subprocess.run(['docker','exec',name,'python','-c',f'import socket; s=socket.create_connection(("127.0.0.1",{port}),3); print(repr(s.recv(12))); s.close()'])
